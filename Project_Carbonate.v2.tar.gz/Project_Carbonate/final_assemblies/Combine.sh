cat *.fa >> combined.fa
